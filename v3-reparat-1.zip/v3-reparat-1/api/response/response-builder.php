<?php
/**
 * Response Builder - DEPRECATED
 * 
 * Acest fișier nu mai este folosit în API v3.
 * Toate funcțiile au fost mutate în utils/helpers.php
 * pentru a evita conflicte de declarare.
 * 
 * Păstrat gol pentru compatibilitate backwards.
 */